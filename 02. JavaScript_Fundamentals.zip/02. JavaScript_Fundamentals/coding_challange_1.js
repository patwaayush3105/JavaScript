let mark_weight = 78
let mark_height = 1.69

let john_weight = 92
let john_height = 1.95

let mark_BMI = mark_weight / (mark_height * mark_height)
let john_BMI = john_weight / (john_height * john_height)

console.log(mark_BMI > john_BMI)